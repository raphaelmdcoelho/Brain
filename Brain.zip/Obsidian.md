## Markdown

* it's possible to use [[Markdown]] language in **Obsidian** notes.
* It's also possible to use [[LaTex]] syntax for math expression.

## Links

* It's possible to create links to another files, using double brakets.

## Tags

* It's possible to create a tag using hashtag symbol, before the word.

#notes #study