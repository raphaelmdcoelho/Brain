Flex is Box with display set to flex and comes with helpful style shorthand. It renders a `div` element.

#frontend #reactjs #chakraui