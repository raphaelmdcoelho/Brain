
* **[[useState]]()**: Handle reactive data, so when data changes re-render the UI.
* **[[useEffect]]()**: This hook will run after a action.

* [[Custom Hooks]]

#frontend #reactjs #hooks 