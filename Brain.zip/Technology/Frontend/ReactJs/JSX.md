Stands for "JavaScript XML"

#frontend #reactjs 