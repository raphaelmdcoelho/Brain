* [[Property Binding]]
* [[Attribute Binding]]
* [[Class and style Binding]]
* [[Event Binding]]
* [[Two-way Binding]]

#frontend #angular #template #binding