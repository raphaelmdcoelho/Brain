```embed
title: "Log In"
image: "https://replit.com/public/images/ogBanner.png"
description: "Run code live in your browser. Write and run code in 50+ languages online with Replit, a powerful IDE, compiler, & interpreter."
url: "https://replit.com/~"
```

```embed
title: "LeetCode - The World’s Leading Online Programming Learning Platform"
image: "https://leetcode.com/static/images/LeetCode_Sharing.png"
description: "Level up your coding skills and quickly land a job. This is the best place to expand your knowledge and get prepared for your next interview."
url: "https://leetcode.com/"
```

```embed
title: "Solve Algorithms Code Challenges"
image: "https://hrcdn.net/og/default.jpg"
description: "The true test of problem solving: when one realizes that time and memory aren’t infinite."
url: "https://www.hackerrank.com/domains/algorithms"
```

```embed
title: "raphaelmdcoelho - Overview"
image: "https://avatars.githubusercontent.com/u/25159405?v=4?s=400"
description: "Full stack developer. raphaelmdcoelho has 6 repositories available. Follow their code on GitHub."
url: "https://github.com/raphaelmdcoelho"
```
