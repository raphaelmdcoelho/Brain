On **pub/sub** systems we have events being generated and cosumed, and in the middle of these operations there is a `topic`.

#messagebroker 
