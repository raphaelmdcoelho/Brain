### Environment

* It's necessary to install `ggc`.
* If using `vscode` is possible to use the extension `code runner`.

### Structure

* Basic `c` code

```c
#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello World!\n");
    return 0;
}
```

#c