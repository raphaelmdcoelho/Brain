<mark>Read Evaluate Print Loop</mark> (console that interprets commands and gives back a result).

- [[Bash]] behaves like REPL, but this terms is more use to describe programming environments for languages like [[Python]], Ruby, or Lisp. Bash is primarily a shell for executing system commands and running shell scripts.

#console 
