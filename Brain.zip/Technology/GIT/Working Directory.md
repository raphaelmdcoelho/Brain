* This tree is in sync with `filesystem`.
* Represents the immediate changes.
* `git status` displays the current status of the working directory.
* `git checkout -- ...` is used to discharge changes in the working directory.

**note**: When working in a Windows OS, it's possible to have some problems with the file names, since Windows doesn't distinguish between upper and lower cases, but Linux does.

#git