* This tree is in sync with filesystem.
* Represents the immediate changes.
* `git status` displays the current status of the working directory.
* `git checkout -- ...` is used to discharge changes in the working directory.

#git