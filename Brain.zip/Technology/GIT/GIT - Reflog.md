
```bash
git reflog
```

#git 