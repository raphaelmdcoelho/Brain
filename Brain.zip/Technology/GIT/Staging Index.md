* This tree tracks the working directory changes, that have been promoted with `git add`.
* It stores the changes to the next commit.
* This tree is a internal complex cache mechanism.
* To see the state of staging index is possible to use the following command: `git ls-files [-s | --stage]`.
* `git reset HEAD ...` can be used to upstage a file.

#git