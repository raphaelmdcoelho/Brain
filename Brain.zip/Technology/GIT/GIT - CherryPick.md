
```bash
git cherry-pick commit-hash
```

#git