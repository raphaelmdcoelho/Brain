* `git commit` add changes to the permanent snapshot that lives in the Commit History.
* `git log` displays the Commit History.

#git