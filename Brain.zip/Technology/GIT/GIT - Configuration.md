
```bash
git config --global alias.ac "commit -am"

// Make case sensitive in windows
git config core.ignorecase false
```

#git 