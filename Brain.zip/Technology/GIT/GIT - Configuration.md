- git config --global alias.ac "commit -am"

#git 