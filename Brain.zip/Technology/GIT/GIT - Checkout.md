
```bash
git checkout -b branch-name
```

#git 