
```bash
git branch -M "name"
git branch
```

#git 