```bash
git merge main

git mergetool
git merge --continue
git merge --abort
```

#git 