
```bash
git commit -am "message"
git commit --amend -m "message"
git commit --amend --no-edit
```

#git 