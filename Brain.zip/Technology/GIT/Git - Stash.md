## Create a stash

```bash
git stash save "your_stash_name"
```

## List stashes

```bash
git stash list
```

## Apply stash

```bash
git stash apply stash@{0}
```

#git