- git log --oneline
- git log --graph --oneline --decorate

#git 