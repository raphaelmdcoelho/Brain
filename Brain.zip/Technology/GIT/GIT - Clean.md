- git clean -df (remove untracked files)
- git check-out -

#git 