```bash
git revert <commit-hash>
```

#git 