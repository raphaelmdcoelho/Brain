- git revert "hash"

#git 