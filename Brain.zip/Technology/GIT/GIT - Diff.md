
**Compare WD with Commit History**: 
```bash
git diff file-name
```
**note**: file-name should have changes in WD.

**Compare Index with Commit History**:
```bash
git diff hash-last-commit(HEAD)
```

#git