***Classes***

- [[Object]]
- [[String]]
- [[Array]]

***Methods***

* [[eval()]]

***Tests***

- [[Jest]]

***Operators***

* [[double exclamation mark]]

***Frameworks***

* [[Bun]]
* [[Node]]

#javascript 
