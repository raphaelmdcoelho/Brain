- The eval() function evaluates Javascript code represented as a string and returns its completion value. the source is parsed as a script.
- Executing Javascript from a string is a enormous security risk.

#javascript 