- [[ECMAScript module system]]
- [[CommonJs]]

#node #javascript 