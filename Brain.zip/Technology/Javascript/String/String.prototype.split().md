- Takes a pattern and divides this String into an ordered list of substring by searching for the pattern.

#javascript 