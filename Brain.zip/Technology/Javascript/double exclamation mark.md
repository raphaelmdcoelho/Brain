The `!!` operator is used to evaluate a expression that not return `boolean` and then return a boolean value. The first exclamation mark is evaluating the expression and the second one is converting to the boolean value like `true` or `false`.

```javascript
// Checking if 0 is true or false:

!0 // brings the oposite value
!!0 // brings the right value in boolean format
```

#javascript 