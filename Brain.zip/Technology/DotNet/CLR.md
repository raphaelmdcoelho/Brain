It provides some runtime services like automatic memory management and exception handling.

C# is called a managed language because after compilation, the result code is called `Intermediate Language` (IL) that is a managed code and then, CLR compiles this IL into native code like x64 or x86. 

#dotnet