* [[IEnumerable]]
* [[Iterator]]
* [[Enumerator]]
* [[IAsyncEnumerable]]

#dotnet #csharp #collections