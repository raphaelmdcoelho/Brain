While the **return** word means “here is the value you asked for this method”, the **yield return** statement means “Here is the next item that you requested from this enumerator”.

#csharp #dotnet