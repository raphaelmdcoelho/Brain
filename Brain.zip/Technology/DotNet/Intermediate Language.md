The container for intermediate code is called assembly.

#dotnet