1. [[Intermediate Language]] (IL).
2. [[C Sharp]] is one of the languages supported by DotNet.
3. [[CLR]] is a runtime for dotnet applications.
4. [[LINQ]]
5. [[Entity Framework]]
6. [[Dependency Injection]]
7. [[Roslyn]]
8. [[DotNet Tool]]
9. [[SignalR]]
10. [[Blazor]]
11. [[Dapper]]
12. [[Autofac]]
13. [[Bogus]]

#dotnet