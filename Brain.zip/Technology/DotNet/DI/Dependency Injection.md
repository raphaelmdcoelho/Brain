* [[IServiceCollection]]

#dotnet #csharp 