### Characteristics

* Built-in dependency management, similar to [[npm]].
* First-class multithreading.
	* Compiler error to improperly access shared data.

<hr>

### [[Rust - Fundamentals - Data Types]]

<hr>

### [[Rust - Fundamentals - Variables]]

<hr>

### [[Rust - Fundamentals - Functions]]

<hr>

### [[Rust - Fundamentals - Println macro]]

<hr>

### [[Rust - Fundamentals - Control flow using if]]

<hr>

### [[Rust - Fundamentals - Repetition using loops]]

<hr>

### [[Rust - Tools instalation]]

<hr>

#rust