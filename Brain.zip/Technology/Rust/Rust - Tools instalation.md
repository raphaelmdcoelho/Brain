* **rustup** (Manages Rust installation)
* **MSVC C++ Build Tools** (Needed to build on Windows)

#rust