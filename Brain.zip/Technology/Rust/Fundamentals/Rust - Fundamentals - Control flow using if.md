```rust
let a = 99;
if a > 99 {
	println!("Big number");
} else if < 5{
	println!("Small number");
} else {
	println!("Other option");
}
```

#rust