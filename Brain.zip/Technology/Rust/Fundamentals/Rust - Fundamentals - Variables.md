* Allows programmer to easily work with memory.

```rust
let two = 2;
let hello = "hello";
let is_active = true;
let mut _my_name = "Bill"; // mutable variable
```

#rust 