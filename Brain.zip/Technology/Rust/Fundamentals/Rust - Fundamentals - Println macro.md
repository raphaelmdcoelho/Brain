Similar to funcitons, except instead of running code they expand into more code.

```rust

// println "Prints" information to the terminal

let life = 42;
println!("hello");
println!("{:?}", life);
println!("{:?} {:?}", life, life);
println!("the meaning is {:?}", life);
println!("{life:?}");
println!("{life}");

// question mark is for debugging and without it is for end user
```

#rust