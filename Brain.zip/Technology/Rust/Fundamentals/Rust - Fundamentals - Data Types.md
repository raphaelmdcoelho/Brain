* Memory only stores binary data
	* Anything can be represented in binary
* Program determines what the binary represents
* Basic types that are universally useful are provided by the language

#rust 