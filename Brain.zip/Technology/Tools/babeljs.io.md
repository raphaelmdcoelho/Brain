Finds out how a [[JSX]] code will be render.

* https://babeljs.io

#frontend #tools 
