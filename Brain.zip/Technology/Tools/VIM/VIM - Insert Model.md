This mode allows you to insert new text.

- Enter Insert mode from Normal mode by pressing `i`.
- Exit back to Normal mode by pressing `Esc`.

#tools #vim 