### Modes

* [[VIM - Normal Mode]]
* [[VIM - Insert Model]]
* [[VIM - Command Mode]]

#tools #texteditor