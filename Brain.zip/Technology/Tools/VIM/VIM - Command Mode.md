This mode allows you to enter commands to save files, quit Vim, etc.

- Enter Command mode from Normal mode by pressing `:`.
- Some common commands include `:w` to save, `:q` to quit, and `:wq` to save and quit.

#tools #vim 