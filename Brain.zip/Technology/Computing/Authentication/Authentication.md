* [[OpenID]]
* [[OAUTH 2.0]]
* [[JWT]]
* [[Cookie]]


#authentication #computing