* [[RAM]]
* [[ROM]]
* [[CPU]]
* [[GPU]]

#computing #hardware
