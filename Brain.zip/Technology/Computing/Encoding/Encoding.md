* [[Character Encodings]]

#encoding #computing 