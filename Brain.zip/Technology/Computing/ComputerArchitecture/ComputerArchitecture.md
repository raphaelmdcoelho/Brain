* [[Firmware]]
* [[BIOS]]
* [[Boot]]
* [[Kernel]]
* [[Drivers]]
* [[Boot Loader]]
* [[GRUB 2]]

#computing #computerarchitecture