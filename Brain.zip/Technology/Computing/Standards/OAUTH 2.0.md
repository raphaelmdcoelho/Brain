#standards #authentication #computing
