#standards #authentication #computing
