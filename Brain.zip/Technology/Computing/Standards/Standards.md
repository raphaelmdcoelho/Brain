* [[OAUTH 2.0]]


#computing #standards 