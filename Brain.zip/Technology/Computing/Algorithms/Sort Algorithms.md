* [[Quick sort]]
* [[Bubble sort]]
* [[Merge sort]]

#computing #algorithms