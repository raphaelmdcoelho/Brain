* [[Binary Search]]

#computing #algorithms