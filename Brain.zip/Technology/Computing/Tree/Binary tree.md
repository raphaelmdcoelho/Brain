- A left knot should have smaller values than parent node. An Right knot should have bigger values than parent node.

```
[61, 43, 89, 16, 51, 66]

            61
           /  \
          43   89
         / \   / 
        16 51 66

[16, 43, 51, 61, 66, 89]
```
- [ ] 
- A binary search could be used in an ordered list.
- Binary tree has logarithmic searches.
- A good root can be the middle of the list.

```
public struct Node
{
	int Data {}
	struct Node Left {}
	struct Node Right {}
}
```

#computing
