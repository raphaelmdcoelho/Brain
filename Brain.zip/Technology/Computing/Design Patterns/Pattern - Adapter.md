Adaptador de objeto
![[Pasted image 20230928230909.png]]
Adaptador de classe
![[Pasted image 20230928230916.png]]
#patterns #computing