É uma classe que deve devolver apenas uma única estância de uma classe específica.
![[Pasted image 20230928230546.png]]
#patterns #computing 