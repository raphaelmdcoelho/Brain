Características intrínsecas (não variável que pode ser compartilhada) e extrínsecas (variável e não pode ser compartilhada).
![[Pasted image 20230928231013.png]]

#patterns #computing