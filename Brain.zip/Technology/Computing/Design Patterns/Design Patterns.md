* [[Patern - Singleton]]
* [[Pattern - Factory Method]]
* [[Pattern - Abstract Factory]]
* [[Patern - Singleton]]
* [[Pattern - Builder]]
* [[Pattern - Prototype]]
* [[Pattern - Adapter]]
* [[Pattern - Flyweight]]

#patterns #computing