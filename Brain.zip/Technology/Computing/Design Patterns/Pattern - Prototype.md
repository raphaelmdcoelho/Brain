É um padrão de projetos utilizado para criar clone de objetos.
![[Pasted image 20230928230801.png]]
#patterns #computing