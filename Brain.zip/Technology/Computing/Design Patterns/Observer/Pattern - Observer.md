### Concepts

![[Pasted image 20231217215532.png]]

### Examples

* [[DP - Observer - Typescript]]
* [[DP - Observer - Python]]
* [[DP - Observer - CSharp]]

#patterns #computing