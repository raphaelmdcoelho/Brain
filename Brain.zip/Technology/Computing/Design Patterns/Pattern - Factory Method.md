- Resumindo ao máximo, trata-se de um método com o retorno de uma interface definida.
- Temos um creator como uma classe abstrata e as classes que IMPLEMENTAM a ela e uma interface de produto que é uma dependência do creator e que possui outras classes que HERDAM dela.

![[Pasted image 20230928230138.png]]
#patterns #computing