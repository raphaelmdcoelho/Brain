We need a AbstractFactory interface that delivers a product interface. All products must have its interface for a given type. The client uses the AbstractConcreteFactory.
![[Pasted image 20230928230308.png]]
We can say that AbstractFactory is a set of Factory methods.
#patterns #computing

