* [[Binary]]

#computing  #numericsystem 