* [[Binary]]

#computing  #numericsystem 