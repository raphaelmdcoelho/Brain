Shift left `<<` multiplies by 2.
Shift right `>>` divides by 2.

#binary #bash 

