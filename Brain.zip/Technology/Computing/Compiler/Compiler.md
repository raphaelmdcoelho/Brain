### Concepts

The main function of a compiler e converting `source code` to `object language` (machine code).

| ==**PROCESSAMENTO DE LINGUAGENS**== |
|--|
| Executable code / Absolute machine code |
| ^ |
| Link editor / Loader |
| ^ |
| Machine Code |
| ^ |
| Assembler |
| ^ |
| Assembly Language |
| ^ |
| Compiler |
| ^ |
| Pure HLL |
| ^ |
| Pre-processor |
| ^|
| HLL |

#computing #compiler
