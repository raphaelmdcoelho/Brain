* 200 - Successful
* 201 - Created
* 204 - No content to sent back
* 4XX - Check what you sent me
* 400 - Bad request
* 401 - Unauthorized, missing credentials
* 403 - Forbidden, You cannot see user information
* 404 - Not found
* 429 - Too many requests
* 500 - Server error
* 502 - Bad gateway
* 503 - Service unavailable
* 3XX - Redirection
* 301 - Redirect
* 302 - Old still works
* 1XX - Informational

#protocols #computing