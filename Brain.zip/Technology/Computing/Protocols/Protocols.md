* [[SMTP]]
* [[TCP]]
* [[IP]]
* [[HTTP - HTTPS]]
* [[UDP]]
* [[RDP]]

#protocols #computing 