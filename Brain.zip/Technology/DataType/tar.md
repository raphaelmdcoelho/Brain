It's a software utility to combine many files into one. Often referred as tarball, but actually means "tape archive". It was originally design to write data to systems without file system.

#datatype 