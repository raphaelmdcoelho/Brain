
### Basic operations

![](https://lh5.googleusercontent.com/ton42ULkMLF96YmxG8y7A6iOw6Yjd8CXKfUxn6czUpvoI5gHuTrOEuZDiSoxn8gF8_ISV8RzOBzO5CbfDS7lkT8RfV9qyooGi7cZqcrNThHQ7vKXCKo_3sYJ3BX3AZwLYqkGu7HIqxXL9D3Xe-vy4c0)

### SQL Execution Order

![[Copy of Screenshot_20231007_221122_Instagram.jpg]]

#sql #database 
