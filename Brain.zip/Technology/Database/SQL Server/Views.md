If necessary to check the database schema, is possible to right-click on the folder "view" and then "new view". After that will be possible to choose the necessary tables to include into the diagram.

#database #sqlserver 