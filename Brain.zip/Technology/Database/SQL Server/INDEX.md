### Concepts


### Usage

**Adding a index**

```sql
CREATE UNIQUE INDEX index1 ON schema1.table1 (column1 DESC, column2 ASC, column3 DESC);
```

**Dropping a index**

```sql
DROP INDEX _table_name_._index_name_;
```

#database #sqlserver 