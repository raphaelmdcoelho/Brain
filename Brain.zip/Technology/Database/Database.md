### Concepts

* [[What is a database]]
* [[SQL]]
### Relational

* [[MongoDB]]
* [[Sqlite]]
* [[SQL Server]]
### NoSql

#sql #database 