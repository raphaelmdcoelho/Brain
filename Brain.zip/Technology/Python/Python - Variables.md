
### Basics
```python

price = 10 # python first allocates a space in memory to a value and then sign it
isPrice = True
print(price)
```

* Use underscore (__) to separate word in the same variable name.

### Input values (from user)
```python
content = input('text to be displayed')
print('text ' + content)
```

#python 