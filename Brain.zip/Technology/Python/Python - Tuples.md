
Tuples are immutable, so you can't change its values.

```python
numbers = [1,2,3]
numbersT = (1,2,3)

numbersT.count()
numbersT.index(1)

numbersT[0]
```

#python 