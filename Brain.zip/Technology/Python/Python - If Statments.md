```python
is_active = True
is_disabled = False

if is_active:
	print("true")
elif is_active and is_disabled:
	print("other option")
else:
	print("false")
```

#python 
