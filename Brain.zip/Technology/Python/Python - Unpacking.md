```python
coordinates = (1,2,3)
x, y, z = coordinates
```

#python 