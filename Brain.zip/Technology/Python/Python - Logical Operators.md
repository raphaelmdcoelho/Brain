```python
if "" and "" or "" and not ""
```

#python 