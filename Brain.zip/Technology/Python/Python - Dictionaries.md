```python
customer = {
	"name": "John Doe",
	"age": 30,
	"is_verified": True
}

customer["name"]
customer.get("name")
```

#python 