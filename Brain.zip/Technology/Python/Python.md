### Concepts

```python

print('message')

print('*' * 10*) # '*' * 10 is a expression, because PRODUCES A VALUE

```

<hr>

* [[Python - Variables]]

* [[Python - Type Conversion]]

* [[Python - Strings]]

* [[Python - Math Functions]]

* [[Python - If Statments]]

* [[Python - Logical Operators]]

* [[Python - Comparison Operators]]

* [[Python - While Loops]]

* [[Python - For Loops]]

* [[Python - Lists]]

* [[Python - Tuples]]

* [[Python - Unpacking]] 

* [[Python - Dictionaries]]

* [[Python - Functions]]

* [[Python - Classes]]

* [[Python - Exceptions]] 

* [[Python - Arguments]]

* [[Python - IO]]
### Libraries

* [[Pandas]]

#python
