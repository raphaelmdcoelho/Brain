```python
number_value = input('value: ')
age = 2023 - int(number_value)
print(age)

print(type(age))

# float()
# bool()
```

#python 