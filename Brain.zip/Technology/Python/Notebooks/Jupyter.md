### Set up

1. Installation via pip
	1. ```pip install jupyter```
2. Launching Jupyter Notebook:
	1. ```jupyter notebook```
	2. This is start the Jupyter server and open your default web browser to the Jupyter dashboard. From here, you can create new notebooks or open existing ones.
3. Using Jupyter Notebook:
	1. Click on 'New' and then 'Python 3'.
	2. To run the code press 'Shift + Enter'.
	3. It's possible to also add markdown cells for text, equations, and other non-code content.
4. Addiontal Feature
	1. It's possible to convert notebooks files to various formats like PDF, HTML, etc.
	2. There are many extensions and plugins which can be installed to enhance its functionality.



#python 