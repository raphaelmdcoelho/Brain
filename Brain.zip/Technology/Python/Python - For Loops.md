```python
for item in range(10):
	print(item)



```

### Nested Loops

```python
for x in range(4):
	for y in range(3):
		print(f'({x}, {y})')
```

#python