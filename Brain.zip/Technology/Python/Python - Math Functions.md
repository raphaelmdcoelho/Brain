```python
import math

x = 2.9
print(round(x))
print(abs(2.9))

math.ceil(2.9)
math.floor(2.9)

# look through python module
```

#python 