#cloud #googlecloud
