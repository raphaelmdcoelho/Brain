* [[Azure Functions]]

#azure #cloud
