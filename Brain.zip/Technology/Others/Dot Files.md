### Concepts

Use to store configuration information for application environments, like .git, .ssh, .vscode, .gitconfig, .zshrc., .bashrc., .env.

### Tips

A good idea is to have all dot files pushed into a repository like [[GitHub]], so if necessary to work from a different station, will be possible to import the configuration from the environment.

note: probably should exists a code or script to apply the need configuration into the app.