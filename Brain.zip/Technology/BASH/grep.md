```bash
cat ./file.txt | grep text
```

#bash 