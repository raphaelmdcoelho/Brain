```bash
export ENV_VARIABLE=Test
echo $ENV_VARIABLE
```

#bash 