The `bc` command is a basic calculator utility in Unix-based systems.

* Can be used typing bc and pr3ssing enter to have the interactive mode.

* There is a possibility to use it in not interactive mode like that:
```bash
echo "2+3" | bc  # Output will be 5
```

#bash 