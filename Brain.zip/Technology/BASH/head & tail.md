```bash
head -n 3 ./file.txt
tail -n 3 ./file.txt
```

#bash