### Syntax

```bash
sleep Number[Suffix]
```

### Examples

There are a couple of different time scales to use:

```bash
sleep 1m

sleep 2h

sleep 5d

sleep 1h 10m 5s
```

#bash 