
```bash
find /home/raphaelcoelho -type f -name "*.txt" -not -path "/home/raphaelcoelho/.*/*"
```

#bash 