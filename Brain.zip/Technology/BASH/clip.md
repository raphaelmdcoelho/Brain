* Can be used to copy a content to clipboard. (It can be used in `Git Bash`).

```bash
clip < file.txt
```

#bash 