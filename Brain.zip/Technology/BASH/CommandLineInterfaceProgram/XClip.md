```bash
xclip -sel c < input_file
```

```bash
xclip -selection clipboard -o > clipboard.txt
```

#commandlineprogram #bash 
