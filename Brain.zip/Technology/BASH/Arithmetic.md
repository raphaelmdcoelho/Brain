```bash
$((1 + 1))
```

#bash 