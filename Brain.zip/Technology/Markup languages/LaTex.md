### Concepts

To use Latext, the formula should be embranced by $ sign, like: $1 + 1 = 2$.

### Useful tags:

* Square root: \sqrt[]{}  ==>  $\sqrt[3]{18}$
* Power: ^  ==> $7^2$

#latex #markup

