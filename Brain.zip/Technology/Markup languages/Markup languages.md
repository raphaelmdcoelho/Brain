All these languages are domain-specific languages (DSL).

* [[Markdown]]
* [[LaTex]]
* [[HTML]]

#markup 
