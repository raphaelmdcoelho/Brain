* [[k8s - controller manager]]
* [[k8s - scheduler]]
* [[k8s - api server]]
* [[k8s - etcd]]

#k8s #container  #orchestration 