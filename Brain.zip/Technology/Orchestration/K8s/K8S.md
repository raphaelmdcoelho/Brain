
* [[k8s - pod]]
* [[k8s - control pane]]

#k8s #container #orchestration 