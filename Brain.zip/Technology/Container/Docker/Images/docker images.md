### Concepts

List all available images on your machine.

# Commands

```bash
docker images
```

#docker #image #container