### Concepts

Save/load an image to/from a [[tar]] archive.

### Commands

```bash
docker save img > image.tar
docker load < image.tar
```

#docker #image #container