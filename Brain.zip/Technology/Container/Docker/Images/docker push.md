### Concepts

Push an image to a registry.

### Commands

```bash
docker push myuser/myimage:latest
```

#docker #image #container