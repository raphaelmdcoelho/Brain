### Concepts

Remove an image from your machine.

### Commands

```bash
docker rmi container_name
```

#docker #image  #container