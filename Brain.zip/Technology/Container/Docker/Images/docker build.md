### Concepts

Build an image from a Dockerfile.
### Commands

```bash
docker build -t myimage:latest
```

#docker #image #container