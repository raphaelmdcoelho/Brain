### Concepts

Pull an image from a registry.
### Commands

```bash
docker pull ubuntu:latest
```

#docker #image #container