### Concepts

### Commands

```bash
docker tag <image_id> my-image:latest
```

#docker #image #container