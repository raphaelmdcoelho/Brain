Will run be run in shell.

Two ways to be expressed:
- RUN command
- RUN ["executable", "parameter"]

#docker #container 