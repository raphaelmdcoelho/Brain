From a Dockerfile:

Allows to add a value to a environment variable.

```dockerfile
ENV MY_NAME="John Doe"
ENV MY_DOG=Rex\ The\ Dog
ENV MY_CAT=fluffy
```

#docker #container 