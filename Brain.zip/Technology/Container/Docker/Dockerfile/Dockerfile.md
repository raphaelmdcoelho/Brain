These are some of the instructions from dockerfile (they have arguments):

- FROM -> Specifies the parent [[Images]]
- [[WORKDIR]]
- [[RUN]]
- COPY
- EXPOSE
- [[CMD]]
- [[ENV]]
- [[ADD]]
- [[VOLUME]]
- [[ENTRYPOINT]]
- [[USER]]
- [[ARG]]

#docker #container 
