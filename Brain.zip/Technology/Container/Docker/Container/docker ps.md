### Concepts

List all running containers.

```bash
docker ps
```

#docker #container 
