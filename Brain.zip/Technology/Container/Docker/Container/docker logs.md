### Concepts

Views the logs for a container.
### Commands

```bash
docker logs container_name
```

#docker #container