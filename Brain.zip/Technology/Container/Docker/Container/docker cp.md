### Concepts

Copy files between container and your logo system.

### Commands

```bash
docker cp container_name://container_path
```

#docker #container 