### Concepts

Run a command in a running container.

### Commands

```bash
docker exec -it [container-id] /bin/bash
```

#docker #container 