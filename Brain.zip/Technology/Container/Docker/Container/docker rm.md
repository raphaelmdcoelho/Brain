### Concepts

Remove a stopped container.

### Commands

```bash
docker rm container_name
```

#docker  #container 