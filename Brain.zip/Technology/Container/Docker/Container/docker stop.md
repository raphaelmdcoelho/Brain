### Concepts

Stop a running container.

### Commands

```bash
docker stop mycontainer
```

#docker #container 