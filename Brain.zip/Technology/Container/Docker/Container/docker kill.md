Forcefully stop a running container.

### Commands

```bash
docker kill container_name
```

#docker  #container 