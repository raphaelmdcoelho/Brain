### Concepts

Restart a running container.

### Commands

```bash
docker restart container_name
```

#docker #container 