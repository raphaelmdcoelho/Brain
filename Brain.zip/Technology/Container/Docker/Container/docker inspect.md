### Concepts

Inspect a container or image.

### Commands

```bash
docker inspect [container_name, image_name]
```

#docker #container #image