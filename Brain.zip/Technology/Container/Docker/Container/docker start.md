### Concepts

Start a stopped container.

### Commands

```bash
docker start container_name
```

#docker #container 