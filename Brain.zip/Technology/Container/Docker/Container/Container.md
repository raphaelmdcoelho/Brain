1. To create a container image is necessary to have a [[Dockerfile]] file that will be build to create a image.
2. A conteinerizacão é possível graças aos [[Namespaces]] do Kernel Linux, que utilizam o [[chroot]] comonparte do processo de isolamento. (Containeres são em essência isolamento).

### Commands

* [[docker run]]
* [[docker exec]]
* [[docker ps]]
* [[docker stop]]
* [[docker start]]
* [[docker restart]]
* [[docker kill]]
* [[docker rm]]
* [[docker logs]]
* [[docker inspect]]
* [[docker cp]]

#docker #container 