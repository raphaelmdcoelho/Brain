Podman is a daemonless, open source, Linux native tool designed to make it easy to find, build, run, build, share and deploy applications using Open Containers Initiative (OCI) containers and containers images. Podman provides a command line Interface familiar to anyone who has used the Docker Container Engine.

#podman #container 