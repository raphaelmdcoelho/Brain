1. [[Intermediate Language]] (IL).
2. [[C Sharp]] is one of the languages supported by DotNet.
3. [[CLR]] is a runtime for dotnet applications.
4. [[LinQ]]

#dotnet