* The extension for Markdown is .md.
* Markdown is a way to format text.
* Can be rendered in HTML or PDF.
* To break link you can use a break line or two spaces in markup code.
* For header it's possible to use the # symbol from 1 to 6. Like:
# Example.

* For bold text it's possible to apply two **wildcards**.
* For italic it's just one *wildcard*.
* For cross off it's possible to use double ~ like: ~~cross off~~.
- To highlight a text it's possible to use doble equal symbol ==highlight== or HTML tag mark like <mark>highlight</mark>.
- to subscript a text it's possible to use the cyrcumflex symbol ^subscript^ or Using HTML like <sup> 2 </sup>
- To create emotional is possible to use semicollumn like :smile: or copy and paste 😁.

#markup 


