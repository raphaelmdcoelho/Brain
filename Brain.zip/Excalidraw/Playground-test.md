---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Hypotenuse ^h7n6Wi1T

Oposite
  Leg ^VXuappSU

Adjacent
   Leg ^w4zPZMZV

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.28",
	"elements": [
		{
			"id": "bLxJ0lhib1s-ga-VRaFk_",
			"type": "line",
			"x": -203.73895054393634,
			"y": 15.03307274387032,
			"width": 374.2105263157895,
			"height": 233.1578947368421,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 1608593310,
			"version": 34,
			"versionNonce": 1077088862,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					374.2105263157895,
					-233.1578947368421
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "S_qGUgPTt5BLe7ECFtXML",
			"type": "line",
			"x": -204.26526633341,
			"y": 16.61202011229136,
			"width": 384.2105263157895,
			"height": 0,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 1890579166,
			"version": 82,
			"versionNonce": 1577339522,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					384.2105263157895,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "MUcXQrU3DkGQKytW4KgOa",
			"type": "line",
			"x": 171.5242073508005,
			"y": -218.65113778244546,
			"width": 0,
			"height": 238.4210526315789,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 1719791362,
			"version": 53,
			"versionNonce": 723326622,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					238.4210526315789
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "bWFkwPLQuzLNxGVo_u3-w",
			"type": "rectangle",
			"x": 149.4189441929057,
			"y": -3.914295677182338,
			"width": 21.57894736842104,
			"height": 21.57894736842104,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"seed": 2095772126,
			"version": 29,
			"versionNonce": 1910221378,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false
		},
		{
			"id": "J2BNFfpRKDqnmaeDaQAdk",
			"type": "freedraw",
			"x": 161.5242073508005,
			"y": 7.664651691238703,
			"width": 0,
			"height": 0.5263157894736992,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1669610754,
			"version": 10,
			"versionNonce": 1790743262,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.5263157894736992
				],
				[
					0,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0,
				0.5263157894736992
			]
		},
		{
			"id": "h7n6Wi1T",
			"type": "text",
			"x": -80.58105580709423,
			"y": -137.07219041402442,
			"width": 106.07987976074219,
			"height": 25,
			"angle": 5.73129773049752,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 396107906,
			"version": 70,
			"versionNonce": 966952734,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"text": "Hypotenuse",
			"rawText": "Hypotenuse",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Hypotenuse",
			"lineHeight": 1.25
		},
		{
			"id": "VXuappSU",
			"type": "text",
			"x": 187.31368103501103,
			"y": -133.38797988770864,
			"width": 72.93991088867188,
			"height": 50,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 544544450,
			"version": 61,
			"versionNonce": 63439774,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754796137,
			"link": null,
			"locked": false,
			"text": "Oposite\n  Leg",
			"rawText": "Oposite\n  Leg",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Oposite\n  Leg",
			"lineHeight": 1.25
		},
		{
			"id": "w4zPZMZV",
			"type": "text",
			"x": -23.738950543936312,
			"y": 32.40149379650194,
			"width": 86.01994323730469,
			"height": 50,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1448748830,
			"version": 60,
			"versionNonce": 664902914,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754793688,
			"link": null,
			"locked": false,
			"text": "Adjacent\n   Leg",
			"rawText": "Adjacent\n   Leg",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Adjacent\n   Leg",
			"lineHeight": 1.25
		},
		{
			"id": "xm726EBwwBCv9W8YTT_dt",
			"type": "freedraw",
			"x": -159.0021084386732,
			"y": -11.282716729813899,
			"width": 16.31578947368422,
			"height": 27.36842105263156,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1002779614,
			"version": 57,
			"versionNonce": 747457346,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754752524,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.5263157894736992,
					0.5263157894736992
				],
				[
					1.05263157894737,
					0.5263157894736992
				],
				[
					1.05263157894737,
					1.0526315789473415
				],
				[
					1.578947368421069,
					1.0526315789473415
				],
				[
					2.10526315789474,
					1.5789473684210407
				],
				[
					2.10526315789474,
					2.10526315789474
				],
				[
					2.631578947368439,
					2.10526315789474
				],
				[
					3.684210526315809,
					2.631578947368439
				],
				[
					3.684210526315809,
					3.1578947368420813
				],
				[
					4.21052631578948,
					3.1578947368420813
				],
				[
					4.736842105263179,
					3.6842105263157805
				],
				[
					4.736842105263179,
					4.21052631578948
				],
				[
					5.789473684210549,
					4.736842105263179
				],
				[
					6.3157894736842195,
					5.263157894736821
				],
				[
					6.3157894736842195,
					5.78947368421052
				],
				[
					6.842105263157919,
					5.78947368421052
				],
				[
					6.842105263157919,
					6.3157894736842195
				],
				[
					7.894736842105289,
					6.842105263157862
				],
				[
					7.894736842105289,
					7.368421052631561
				],
				[
					8.42105263157896,
					8.42105263157896
				],
				[
					8.42105263157896,
					8.947368421052602
				],
				[
					8.94736842105263,
					9.4736842105263
				],
				[
					9.47368421052633,
					9.4736842105263
				],
				[
					9.47368421052633,
					10
				],
				[
					10,
					10.5263157894737
				],
				[
					10,
					11.052631578947341
				],
				[
					10.5263157894737,
					12.10526315789474
				],
				[
					11.05263157894737,
					12.631578947368439
				],
				[
					11.578947368421069,
					13.157894736842081
				],
				[
					12.10526315789474,
					14.21052631578948
				],
				[
					12.631578947368439,
					14.736842105263122
				],
				[
					12.631578947368439,
					15.263157894736821
				],
				[
					13.15789473684211,
					16.31578947368422
				],
				[
					13.684210526315809,
					16.842105263157862
				],
				[
					13.684210526315809,
					17.36842105263156
				],
				[
					14.21052631578948,
					18.42105263157896
				],
				[
					14.21052631578948,
					18.9473684210526
				],
				[
					14.736842105263179,
					19.4736842105263
				],
				[
					14.736842105263179,
					20
				],
				[
					14.736842105263179,
					20.5263157894737
				],
				[
					14.736842105263179,
					21.05263157894734
				],
				[
					15.26315789473685,
					21.57894736842104
				],
				[
					15.26315789473685,
					22.63157894736844
				],
				[
					15.26315789473685,
					23.15789473684208
				],
				[
					15.26315789473685,
					23.68421052631578
				],
				[
					15.26315789473685,
					24.21052631578948
				],
				[
					15.26315789473685,
					24.736842105263122
				],
				[
					15.26315789473685,
					25.26315789473682
				],
				[
					15.26315789473685,
					25.78947368421052
				],
				[
					15.26315789473685,
					26.31578947368422
				],
				[
					15.26315789473685,
					26.842105263157862
				],
				[
					15.789473684210549,
					26.842105263157862
				],
				[
					15.789473684210549,
					27.36842105263156
				],
				[
					16.31578947368422,
					27.36842105263156
				],
				[
					16.31578947368422,
					27.36842105263156
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				16.31578947368422,
				27.36842105263156
			]
		},
		{
			"id": "_V5qeQ6CEzrqzYIcOLcF1",
			"type": "freedraw",
			"x": -93.73895054393637,
			"y": 3.454125375449223,
			"width": 30,
			"height": 21.05263157894734,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 916559390,
			"version": 61,
			"versionNonce": 2010944514,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1699754754876,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.5263157894736423
				],
				[
					-0.5263157894736423,
					-1.0526315789473415
				],
				[
					-1.0526315789473415,
					-2.631578947368382
				],
				[
					-1.5789473684210407,
					-3.1578947368420813
				],
				[
					-2.105263157894683,
					-4.210526315789423
				],
				[
					-3.1578947368420813,
					-5.78947368421052
				],
				[
					-4.210526315789423,
					-7.89473684210526
				],
				[
					-5.263157894736821,
					-8.947368421052602
				],
				[
					-6.315789473684163,
					-9.4736842105263
				],
				[
					-7.89473684210526,
					-11.052631578947341
				],
				[
					-8.947368421052602,
					-11.57894736842104
				],
				[
					-9.999999999999943,
					-12.631578947368382
				],
				[
					-10.526315789473642,
					-13.157894736842081
				],
				[
					-11.57894736842104,
					-14.210526315789423
				],
				[
					-13.157894736842081,
					-15.263157894736821
				],
				[
					-14.210526315789423,
					-15.78947368421052
				],
				[
					-14.736842105263122,
					-15.78947368421052
				],
				[
					-15.78947368421052,
					-15.78947368421052
				],
				[
					-16.315789473684163,
					-16.315789473684163
				],
				[
					-17.36842105263156,
					-16.315789473684163
				],
				[
					-18.9473684210526,
					-16.315789473684163
				],
				[
					-19.4736842105263,
					-16.315789473684163
				],
				[
					-20.526315789473642,
					-16.315789473684163
				],
				[
					-21.05263157894734,
					-16.315789473684163
				],
				[
					-21.57894736842104,
					-16.315789473684163
				],
				[
					-22.105263157894683,
					-15.263157894736821
				],
				[
					-23.68421052631578,
					-13.68421052631578
				],
				[
					-23.68421052631578,
					-13.157894736842081
				],
				[
					-24.210526315789423,
					-12.631578947368382
				],
				[
					-24.210526315789423,
					-11.57894736842104
				],
				[
					-24.210526315789423,
					-11.052631578947341
				],
				[
					-24.210526315789423,
					-10.526315789473642
				],
				[
					-24.210526315789423,
					-9.4736842105263
				],
				[
					-24.210526315789423,
					-8.947368421052602
				],
				[
					-24.210526315789423,
					-8.421052631578902
				],
				[
					-24.210526315789423,
					-7.89473684210526
				],
				[
					-23.68421052631578,
					-7.368421052631561
				],
				[
					-23.15789473684208,
					-6.842105263157862
				],
				[
					-22.105263157894683,
					-6.315789473684163
				],
				[
					-20.526315789473642,
					-5.78947368421052
				],
				[
					-19.999999999999943,
					-5.78947368421052
				],
				[
					-18.421052631578902,
					-5.78947368421052
				],
				[
					-17.36842105263156,
					-5.78947368421052
				],
				[
					-16.315789473684163,
					-5.78947368421052
				],
				[
					-14.736842105263122,
					-5.78947368421052
				],
				[
					-13.157894736842081,
					-6.842105263157862
				],
				[
					-10.526315789473642,
					-8.421052631578902
				],
				[
					-9.4736842105263,
					-8.947368421052602
				],
				[
					-6.842105263157862,
					-11.052631578947341
				],
				[
					-4.210526315789423,
					-12.631578947368382
				],
				[
					-3.1578947368420813,
					-14.210526315789423
				],
				[
					-2.105263157894683,
					-14.736842105263122
				],
				[
					-1.0526315789473415,
					-15.78947368421052
				],
				[
					0,
					-17.36842105263156
				],
				[
					1.5789473684210975,
					-17.89473684210526
				],
				[
					3.6842105263158373,
					-18.9473684210526
				],
				[
					4.736842105263179,
					-19.999999999999943
				],
				[
					5.789473684210577,
					-21.05263157894734
				],
				[
					5.789473684210577,
					-21.05263157894734
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				5.789473684210577,
				-21.05263157894734
			]
		},
		{
			"type": "ellipse",
			"version": 99,
			"versionNonce": 1445056734,
			"isDeleted": true,
			"id": "G6PSV6FiVuCNSSA9bgJWt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -166.75,
			"y": -260.2421875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 422,
			"height": 411,
			"seed": 1347258242,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 98,
			"versionNonce": 1917236226,
			"isDeleted": true,
			"id": "h1IkUV2W9AfQUpgsVHyUQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 33.25,
			"y": -271.2421875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 12,
			"height": 439,
			"seed": 1260416030,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12,
					439
				]
			]
		},
		{
			"type": "line",
			"version": 87,
			"versionNonce": 1102054686,
			"isDeleted": true,
			"id": "_562Y2D3VuUBeXUvgdqD3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -185.75,
			"y": -60.2421875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 468,
			"height": 3,
			"seed": 149554718,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					468,
					-3
				]
			]
		},
		{
			"type": "line",
			"version": 222,
			"versionNonce": 1964303298,
			"isDeleted": true,
			"id": "wRqdlSoZh9teWDmWBgiIs",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 258.35973366659,
			"y": -36.33311416509713,
			"strokeColor": "#2f9e44",
			"backgroundColor": "#ffec99",
			"width": 8.5,
			"height": 270,
			"seed": 757703938,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-8.5,
					-270
				]
			]
		},
		{
			"type": "line",
			"version": 108,
			"versionNonce": 1038987614,
			"isDeleted": true,
			"id": "W6nRMGGRi2njvL99Pgh9N",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 39.85973366658999,
			"y": -63.30679837562343,
			"strokeColor": "#f08c00",
			"backgroundColor": "#ffec99",
			"width": 138.5,
			"height": 150.5,
			"seed": 37254686,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					138.5,
					-150.5
				]
			]
		},
		{
			"type": "line",
			"version": 90,
			"versionNonce": 638000002,
			"isDeleted": true,
			"id": "l21dcVn9PuSp75w3RH6oE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 179.85973366659,
			"y": -214.30679837562343,
			"strokeColor": "#f08c00",
			"backgroundColor": "#ffec99",
			"width": 70.5,
			"height": 84,
			"seed": 535273666,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					70.5,
					-84
				]
			]
		},
		{
			"type": "text",
			"version": 78,
			"versionNonce": 1982584222,
			"isDeleted": true,
			"id": "RYD1xHow",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 204.46499682448467,
			"y": -226.54364048088658,
			"strokeColor": "#2f9e44",
			"backgroundColor": "#ffec99",
			"width": 38.759979248046875,
			"height": 25,
			"seed": 2086656222,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Tan",
			"rawText": "Tan",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Tan",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "ellipse",
			"version": 34,
			"versionNonce": 861690690,
			"isDeleted": true,
			"id": "ru8jAEwPHKkznDMO-4VZz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 174.35973366659,
			"y": -216.30679837562343,
			"strokeColor": "#f08c00",
			"backgroundColor": "#ffc9c9",
			"width": 6.5,
			"height": 6.5,
			"seed": 952296862,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 86,
			"versionNonce": 60518878,
			"isDeleted": true,
			"id": "mWR2YCBc",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 78.27594835095732,
			"y": -96.13530196226833,
			"strokeColor": "#f08c00",
			"backgroundColor": "#ffc9c9",
			"width": 33.13996887207031,
			"height": 25,
			"seed": 574482654,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sec",
			"rawText": "Sec",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sec",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 30,
			"versionNonce": 728998658,
			"isDeleted": true,
			"id": "7KfNQvsc",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 231.47539295348122,
			"y": -96.3030013739417,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 633859906,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 29,
			"versionNonce": 827164190,
			"isDeleted": true,
			"id": "xA8Fe9gd",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -148.81708799673947,
			"y": -91.64092192271306,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"width": 13.639984130859375,
			"height": 25,
			"seed": 544834654,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "-1",
			"rawText": "-1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "-1",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"id": "gkdfuYrD-sFUmoxUfB0B0",
			"type": "line",
			"x": -141.10737159656793,
			"y": 2.927809585975581,
			"width": 288.42105263157896,
			"height": 205.26315789473682,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffc9c9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 790844162,
			"version": 38,
			"versionNonce": 2026631874,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					288.42105263157896,
					-205.26315789473682
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "SXUNqHKEUiZnLddLV6Gb6",
			"type": "freedraw",
			"x": -143.21263475446264,
			"y": -134.440611466656,
			"width": 0.0001,
			"height": 0.0001,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1092237662,
			"version": 8,
			"versionNonce": 456200706,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0.0001,
				0.0001
			]
		},
		{
			"id": "mDTP9e15Rss9WSuJ5NS5g",
			"type": "freedraw",
			"x": -148.4757926491995,
			"y": -17.59850620349812,
			"width": 18.94736842105263,
			"height": 26.31578947368422,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1259025538,
			"version": 53,
			"versionNonce": 1114765698,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.5263157894736992
				],
				[
					0.5263157894736707,
					0.5263157894736992
				],
				[
					1.05263157894737,
					1.0526315789473983
				],
				[
					1.5789473684210407,
					1.5789473684210407
				],
				[
					2.10526315789474,
					1.5789473684210407
				],
				[
					3.1578947368421098,
					2.631578947368439
				],
				[
					3.6842105263157805,
					3.1578947368420813
				],
				[
					4.21052631578948,
					3.1578947368420813
				],
				[
					4.21052631578948,
					3.6842105263157805
				],
				[
					4.73684210526315,
					3.6842105263157805
				],
				[
					5.26315789473685,
					3.6842105263157805
				],
				[
					5.26315789473685,
					4.21052631578948
				],
				[
					5.78947368421052,
					4.21052631578948
				],
				[
					6.3157894736842195,
					4.736842105263179
				],
				[
					7.368421052631561,
					5.263157894736821
				],
				[
					7.89473684210526,
					5.78947368421052
				],
				[
					8.421052631578931,
					5.78947368421052
				],
				[
					8.94736842105263,
					6.3157894736842195
				],
				[
					9.4736842105263,
					6.3157894736842195
				],
				[
					10,
					6.842105263157919
				],
				[
					10,
					7.368421052631561
				],
				[
					10.52631578947367,
					7.89473684210526
				],
				[
					11.05263157894737,
					8.947368421052659
				],
				[
					11.57894736842104,
					9.4736842105263
				],
				[
					12.10526315789474,
					10
				],
				[
					12.63157894736841,
					10.5263157894737
				],
				[
					12.63157894736841,
					11.052631578947398
				],
				[
					13.15789473684211,
					11.57894736842104
				],
				[
					13.68421052631578,
					12.10526315789474
				],
				[
					14.21052631578948,
					13.157894736842081
				],
				[
					14.21052631578948,
					13.68421052631578
				],
				[
					15.26315789473685,
					14.736842105263179
				],
				[
					15.26315789473685,
					15.78947368421052
				],
				[
					15.78947368421052,
					16.31578947368422
				],
				[
					15.78947368421052,
					17.36842105263156
				],
				[
					16.31578947368422,
					18.42105263157896
				],
				[
					16.84210526315789,
					19.4736842105263
				],
				[
					17.36842105263156,
					20.5263157894737
				],
				[
					17.36842105263156,
					21.57894736842104
				],
				[
					17.36842105263156,
					22.10526315789474
				],
				[
					17.89473684210526,
					23.15789473684208
				],
				[
					18.42105263157893,
					24.21052631578948
				],
				[
					18.42105263157893,
					25.26315789473682
				],
				[
					18.42105263157893,
					25.78947368421052
				],
				[
					18.94736842105263,
					25.78947368421052
				],
				[
					18.94736842105263,
					26.31578947368422
				],
				[
					18.94736842105263,
					26.31578947368422
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				18.94736842105263,
				26.31578947368422
			]
		},
		{
			"id": "laeVT0JEX05d4Bb7w4UbQ",
			"type": "freedraw",
			"x": -150.05474001762056,
			"y": -15.493243045603379,
			"width": 19.47368421052633,
			"height": 30,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1749561666,
			"version": 63,
			"versionNonce": 1357240222,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754748818,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					0.5263157894736992
				],
				[
					0,
					1.0526315789473415
				],
				[
					0.5263157894736992,
					1.0526315789473415
				],
				[
					1.05263157894737,
					1.5789473684210407
				],
				[
					1.578947368421069,
					1.5789473684210407
				],
				[
					2.10526315789474,
					2.10526315789474
				],
				[
					2.631578947368439,
					2.631578947368439
				],
				[
					4.21052631578948,
					3.6842105263157805
				],
				[
					4.736842105263179,
					4.21052631578948
				],
				[
					5.26315789473685,
					4.736842105263179
				],
				[
					5.789473684210549,
					4.736842105263179
				],
				[
					5.789473684210549,
					5.263157894736821
				],
				[
					6.3157894736842195,
					5.263157894736821
				],
				[
					6.3157894736842195,
					5.78947368421052
				],
				[
					7.368421052631589,
					6.3157894736842195
				],
				[
					7.368421052631589,
					6.842105263157919
				],
				[
					7.894736842105289,
					6.842105263157919
				],
				[
					7.894736842105289,
					7.368421052631561
				],
				[
					8.42105263157896,
					7.89473684210526
				],
				[
					9.47368421052633,
					8.42105263157896
				],
				[
					9.47368421052633,
					8.947368421052659
				],
				[
					10,
					9.4736842105263
				],
				[
					10.5263157894737,
					10
				],
				[
					11.578947368421069,
					11.052631578947341
				],
				[
					12.10526315789474,
					11.57894736842104
				],
				[
					12.10526315789474,
					12.10526315789474
				],
				[
					12.631578947368439,
					12.631578947368439
				],
				[
					13.15789473684211,
					13.68421052631578
				],
				[
					13.684210526315809,
					14.21052631578948
				],
				[
					14.21052631578948,
					15.263157894736821
				],
				[
					14.736842105263179,
					15.78947368421052
				],
				[
					14.736842105263179,
					16.84210526315792
				],
				[
					15.26315789473685,
					17.89473684210526
				],
				[
					15.789473684210549,
					18.42105263157896
				],
				[
					15.789473684210549,
					18.9473684210526
				],
				[
					16.31578947368422,
					20
				],
				[
					16.31578947368422,
					20.5263157894737
				],
				[
					16.31578947368422,
					21.05263157894734
				],
				[
					16.84210526315792,
					21.57894736842104
				],
				[
					17.36842105263159,
					21.57894736842104
				],
				[
					17.36842105263159,
					22.10526315789474
				],
				[
					17.36842105263159,
					22.63157894736844
				],
				[
					17.89473684210529,
					23.15789473684208
				],
				[
					17.89473684210529,
					23.68421052631578
				],
				[
					17.89473684210529,
					24.21052631578948
				],
				[
					17.89473684210529,
					24.73684210526318
				],
				[
					18.42105263157896,
					25.26315789473682
				],
				[
					18.42105263157896,
					25.78947368421052
				],
				[
					18.42105263157896,
					26.31578947368422
				],
				[
					18.42105263157896,
					26.84210526315792
				],
				[
					18.42105263157896,
					27.36842105263156
				],
				[
					18.94736842105263,
					27.89473684210526
				],
				[
					18.94736842105263,
					28.42105263157896
				],
				[
					18.94736842105263,
					28.9473684210526
				],
				[
					18.94736842105263,
					29.4736842105263
				],
				[
					19.47368421052633,
					29.4736842105263
				],
				[
					19.47368421052633,
					30
				],
				[
					19.47368421052633,
					30
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				19.47368421052633,
				30
			]
		},
		{
			"id": "zORBAmJ_24evsCNH1_fCQ",
			"type": "freedraw",
			"x": -82.68631896498897,
			"y": -0.7564009403401997,
			"width": 35.26315789473682,
			"height": 22.10526315789474,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1157452354,
			"version": 93,
			"versionNonce": 1220937886,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754744595,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.5263157894736992
				],
				[
					-0.5263157894736992,
					-1.0526315789473983
				],
				[
					-1.0526315789473983,
					-2.10526315789474
				],
				[
					-1.0526315789473983,
					-2.631578947368439
				],
				[
					-2.10526315789474,
					-4.21052631578948
				],
				[
					-2.631578947368439,
					-5.263157894736878
				],
				[
					-3.1578947368420813,
					-5.78947368421052
				],
				[
					-3.6842105263157805,
					-5.78947368421052
				],
				[
					-3.6842105263157805,
					-6.3157894736842195
				],
				[
					-4.736842105263179,
					-7.368421052631618
				],
				[
					-6.3157894736842195,
					-8.42105263157896
				],
				[
					-6.842105263157919,
					-8.947368421052659
				],
				[
					-7.368421052631561,
					-10
				],
				[
					-8.42105263157896,
					-10.5263157894737
				],
				[
					-8.947368421052659,
					-10.5263157894737
				],
				[
					-10,
					-11.578947368421098
				],
				[
					-10.5263157894737,
					-12.10526315789474
				],
				[
					-11.57894736842104,
					-12.631578947368439
				],
				[
					-13.157894736842081,
					-13.157894736842138
				],
				[
					-14.21052631578948,
					-13.684210526315837
				],
				[
					-14.736842105263179,
					-14.21052631578948
				],
				[
					-15.78947368421052,
					-15.263157894736878
				],
				[
					-16.84210526315792,
					-15.263157894736878
				],
				[
					-17.89473684210526,
					-16.31578947368422
				],
				[
					-18.94736842105266,
					-16.31578947368422
				],
				[
					-19.4736842105263,
					-16.84210526315792
				],
				[
					-20,
					-16.84210526315792
				],
				[
					-21.05263157894734,
					-17.368421052631618
				],
				[
					-21.57894736842104,
					-17.368421052631618
				],
				[
					-22.63157894736844,
					-17.368421052631618
				],
				[
					-23.68421052631578,
					-17.368421052631618
				],
				[
					-25.26315789473682,
					-17.368421052631618
				],
				[
					-26.31578947368422,
					-17.368421052631618
				],
				[
					-27.36842105263156,
					-17.368421052631618
				],
				[
					-27.89473684210526,
					-17.368421052631618
				],
				[
					-28.42105263157896,
					-17.368421052631618
				],
				[
					-28.94736842105266,
					-17.368421052631618
				],
				[
					-29.4736842105263,
					-17.368421052631618
				],
				[
					-29.4736842105263,
					-16.84210526315792
				],
				[
					-30.5263157894737,
					-16.31578947368422
				],
				[
					-31.05263157894734,
					-16.31578947368422
				],
				[
					-31.05263157894734,
					-15.78947368421052
				],
				[
					-31.05263157894734,
					-15.263157894736878
				],
				[
					-31.57894736842104,
					-15.263157894736878
				],
				[
					-31.57894736842104,
					-14.736842105263179
				],
				[
					-31.57894736842104,
					-14.21052631578948
				],
				[
					-31.57894736842104,
					-13.684210526315837
				],
				[
					-31.57894736842104,
					-13.157894736842138
				],
				[
					-31.57894736842104,
					-12.631578947368439
				],
				[
					-31.57894736842104,
					-12.10526315789474
				],
				[
					-31.57894736842104,
					-11.052631578947398
				],
				[
					-31.57894736842104,
					-10.5263157894737
				],
				[
					-31.57894736842104,
					-9.473684210526358
				],
				[
					-31.57894736842104,
					-8.947368421052659
				],
				[
					-31.57894736842104,
					-8.42105263157896
				],
				[
					-31.05263157894734,
					-8.42105263157896
				],
				[
					-30.5263157894737,
					-8.42105263157896
				],
				[
					-30.5263157894737,
					-7.89473684210526
				],
				[
					-30,
					-6.842105263157919
				],
				[
					-28.94736842105266,
					-6.3157894736842195
				],
				[
					-27.36842105263156,
					-5.78947368421052
				],
				[
					-25.78947368421052,
					-4.736842105263179
				],
				[
					-25.26315789473682,
					-4.736842105263179
				],
				[
					-24.21052631578948,
					-4.21052631578948
				],
				[
					-22.63157894736844,
					-4.21052631578948
				],
				[
					-22.10526315789474,
					-4.21052631578948
				],
				[
					-20,
					-4.21052631578948
				],
				[
					-18.94736842105266,
					-4.21052631578948
				],
				[
					-18.42105263157896,
					-4.21052631578948
				],
				[
					-17.36842105263156,
					-4.21052631578948
				],
				[
					-15.78947368421052,
					-5.263157894736878
				],
				[
					-14.736842105263179,
					-5.78947368421052
				],
				[
					-13.157894736842081,
					-6.3157894736842195
				],
				[
					-12.10526315789474,
					-7.368421052631618
				],
				[
					-11.052631578947398,
					-7.89473684210526
				],
				[
					-11.052631578947398,
					-8.42105263157896
				],
				[
					-10,
					-9.473684210526358
				],
				[
					-9.4736842105263,
					-10.5263157894737
				],
				[
					-8.42105263157896,
					-11.052631578947398
				],
				[
					-7.89473684210526,
					-12.10526315789474
				],
				[
					-7.368421052631561,
					-13.157894736842138
				],
				[
					-6.3157894736842195,
					-14.736842105263179
				],
				[
					-5.263157894736821,
					-15.78947368421052
				],
				[
					-3.1578947368420813,
					-17.368421052631618
				],
				[
					-1.0526315789473983,
					-18.94736842105266
				],
				[
					0.5263157894736992,
					-20
				],
				[
					2.631578947368439,
					-21.0526315789474
				],
				[
					3.1578947368420813,
					-22.10526315789474
				],
				[
					3.6842105263157805,
					-22.10526315789474
				],
				[
					3.6842105263157805,
					-22.10526315789474
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				3.6842105263157805,
				-22.10526315789474
			]
		},
		{
			"id": "fG1-Spk3m8gnbNOenf1cM",
			"type": "freedraw",
			"x": -27.94947685972579,
			"y": -6.54587462455072,
			"width": 69.4736842105263,
			"height": 48.42105263157896,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1865580546,
			"version": 36,
			"versionNonce": 2043810974,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1699754748393,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-1.0526315789473983
				],
				[
					0,
					-2.631578947368439
				],
				[
					-1.0526315789473983,
					-3.6842105263158373
				],
				[
					-5.263157894736878,
					-10
				],
				[
					-10.5263157894737,
					-14.736842105263179
				],
				[
					-18.42105263157896,
					-21.578947368421098
				],
				[
					-24.73684210526318,
					-26.84210526315792
				],
				[
					-38.94736842105266,
					-36.84210526315792
				],
				[
					-46.31578947368422,
					-40
				],
				[
					-51.0526315789474,
					-40.5263157894737
				],
				[
					-51.5789473684211,
					-40.5263157894737
				],
				[
					-53.68421052631584,
					-38.42105263157896
				],
				[
					-55.78947368421058,
					-33.68421052631584
				],
				[
					-57.36842105263162,
					-28.42105263157896
				],
				[
					-58.42105263157896,
					-21.578947368421098
				],
				[
					-58.94736842105266,
					-18.42105263157896
				],
				[
					-58.94736842105266,
					-13.684210526315837
				],
				[
					-58.42105263157896,
					-11.052631578947398
				],
				[
					-57.36842105263162,
					-9.473684210526358
				],
				[
					-54.73684210526318,
					-7.894736842105317
				],
				[
					-52.10526315789474,
					-7.894736842105317
				],
				[
					-45.78947368421058,
					-7.894736842105317
				],
				[
					-37.89473684210526,
					-10
				],
				[
					-32.10526315789474,
					-12.10526315789474
				],
				[
					-24.73684210526318,
					-16.84210526315792
				],
				[
					-17.368421052631618,
					-21.578947368421098
				],
				[
					-12.10526315789474,
					-26.31578947368422
				],
				[
					-6.842105263157919,
					-32.10526315789474
				],
				[
					1.0526315789473415,
					-40.5263157894737
				],
				[
					5.263157894736821,
					-44.73684210526318
				],
				[
					8.947368421052602,
					-47.89473684210526
				],
				[
					10.526315789473642,
					-48.42105263157896
				],
				[
					10.526315789473642,
					-48.42105263157896
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				10.526315789473642,
				-48.42105263157896
			]
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#2f9e44",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 375.05474001762053,
		"scrollY": 319.9751509403402,
		"zoom": {
			"value": 1.9000000000000001
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%