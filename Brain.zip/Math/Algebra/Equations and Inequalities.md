* One step addition & subtraction Equations:

$x + 7 = 10$
$x + 7 - 7 = 10 - 7$
<mark>$x = 3$</mark>

$a - 5 = -2$
$a -5 + 5 = -2 + 5$
<mark>$a = 3$</mark>

$a + 5 = 54$
$a + 5 - 5 = 54 - 5$
<mark>$a = 49$</mark>

# References

* https://pt.khanacademy.org/

#math 