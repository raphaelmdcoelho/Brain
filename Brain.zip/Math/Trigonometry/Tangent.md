### Concepts

It's the length of the vertical tangent straight until touches secant projection.

![[Pasted image 20231111225132.png]]

#math #trigonometry 