### Concepts

Projection from the Radius until touch Tangent straight.

![[Pasted image 20231111225132.png]]

#math #trigonometry 