### Concepts

It's the vertical projection on a trigonometry circle.

![[Pasted image 20231111222126.png]]

#math #trigonometry 