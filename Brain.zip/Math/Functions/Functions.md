A function it's a rule to associate two sets.

```functionplot
---
title: Example
xLabel: X
yLabel: Y
bounds: [-10,10,-10,10]
disableZoom: false
grid: false
---
F(x) = 2 * x
F2(x) = 1 * x
F3(x) = x * x
```


#math #function