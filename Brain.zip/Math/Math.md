
* [[Power]]
* [[Root]]

#math
