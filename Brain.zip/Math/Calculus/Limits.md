### Concepts

Limit it's the procedure of approximately a number to another one, like:

1  -->  $\sqrt{2}$  <--  2

An important concept to understand limits are [[Functions]].

$\lim {x \to \ell }f(x)=L$

#math 
