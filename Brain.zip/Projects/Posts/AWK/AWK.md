* when developed => Bell Labs, in 1970s
* name: derived from its creators: Alfred Aho, Peter Weinberger, and Brian Kernighan.
* AWK is a domain-specific language (DSL). That mean it was created to resolve a specific problem instead of General Purpose Languages (GPLs) like Java.
* goal: text processing (transforms) and data extraction. (can be use to generate report)
* check line by line of a file and looks for a PATTERN. When pattern is find, the ACTION is applied.
* awk is a standalone utility
* data driven script language


**Basic syntax**
=> pattern, action, file

**Goal**
**t**
**References**

#posts #projects 
