## Concepts

- Root (Root do file system)
## Types

- [[Binary tree]]

#computing 