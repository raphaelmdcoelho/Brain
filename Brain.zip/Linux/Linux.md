1. [[chroot]]
2. [[Namespaces]]
3. [[chown]]
4. [[chmod]]
5. [[SSH keys]]

#linux 