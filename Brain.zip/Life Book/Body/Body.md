## Goals

### 2024

* loss weight

| Month | Weight | Goal | It was achieved | 
|---|---|---|---|
| January  | | |✅ |
| February | | | ❌|

#lifebook #body