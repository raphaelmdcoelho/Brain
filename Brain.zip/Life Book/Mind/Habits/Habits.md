### Component Habits

* Trigger
* Routine
* Reward

### Steps to make habits easy to create

* **Procedural Memory**: Visualize the task you should do, in small steps, to make easier to start it.
* **Increase dopamine**: Visualize the results and how you will feel better, after the task.
* **Need to sleep better :(** 

#lifebook #mind #habits
