### Books

* [[Books - 2023]]

### Medium

* [[MediumArticles]]

### Habits

* [[Habits]]

### Discipline

* [[Discipline]]

#lifebook #mind