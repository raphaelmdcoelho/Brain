* If you feel laziness, just think: "Today, I will do even more!", "Today I will not give up, if I really want this, I will give up tomorrow!".
* There is no problem that can be solved having bad feeling and thoughts.
* Avoid block for a routine, thinking in what I need, before. Always be ahead for difficulties that can happens in the future.

#lifebook #mind 