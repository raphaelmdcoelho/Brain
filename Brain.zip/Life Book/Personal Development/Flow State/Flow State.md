### Concepts

Often related with a high state of productivity.
### How to get there

* Eliminate distractions.
* Have a clear, specific goal in mind.
* Pre-flow Rituals
	* Have a routine to start the flow state.
* Focus on the present moment.
* Rewards and Achievements (positive feedback, achievements recognized, reach milestones).
* Alternate time and energy (switch between "in flow state" and "not bein in it").

#lifebook #personaldevelopment