#instruments #guitar #skills #lifebook  #personaldevelopment 
