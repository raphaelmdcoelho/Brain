### Mind

* [[Flow State]]

### Tasks

* [[Life Book/Personal Development/Time Management/Time Management|Time Management]]

### Skills

* [[Draw]]
* [[Guitar]]

#lifebook #personaldevelopment 