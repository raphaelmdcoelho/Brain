* Soak the raw legumes for 12 hours (beans, peas).
* Avoid to have milk, cheese (calcium source) and meat and legumes (iron source) in the same plate.

#lifebook #health #food