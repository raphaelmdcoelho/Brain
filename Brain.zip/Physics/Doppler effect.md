Red -> if object is faster then observer, then the wave length should be longer, what means, low frequency, so red color (infra red).

Blue -> if object is slowest then observer, then the wave length should be shorter, what means, high frequency, so blue color (ultra violet).

#wave #physics 