* [[Doppler effect]]

#wave #physics 