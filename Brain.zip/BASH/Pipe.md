Pipe allows communication between a stdout of a process with the stdin of another process.

```cal | wc -l```

#bash 