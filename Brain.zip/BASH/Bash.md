1. Born do SHELL again is a piece of software and a language, so through the PROMPT is possible to send command for SHELL and it'll communicates with the processor.
2. The bash language have a lot of keywords and expressions:
3. With [[Redirection]] is possible to receive or send some information from/to stdin and stdout.
4. To run scripts in parallel it's possible to use the & or && operators.
5. The [[For statement]] is used to iterate trough a collection and realize some specific code for each element.
6. The [[If statment]] is used to have a condicional choice in the code.
7. The [[Alias]].
8. The [[While statment]] allows to iterate based on a condition.
9. [[Pipe]].
10. Run [[Scripts in parallel]].
11. [[Sleep]].

- [[BASH Shortcuts]]

#bash 