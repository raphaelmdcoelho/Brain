- Temporay:
```alias ll='-ls -ls'```
- Persistence:
~/.bashrc or ~/.bash_aliases

#bash
