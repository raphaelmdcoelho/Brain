while read LREAD; do
	echo "$LREAD" 
done < ./test.txt

#bash 