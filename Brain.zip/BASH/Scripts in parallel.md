- &&
- &

#bash 