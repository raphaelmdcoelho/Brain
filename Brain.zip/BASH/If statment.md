`if [ ! -e ./*.sql ]; the echo "message"; fi`

#bash 