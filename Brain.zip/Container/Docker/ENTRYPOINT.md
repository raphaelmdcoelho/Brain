From a Dockerfile:

Allows the container to run as a executable.

ENTRYPOINT ["executable", "param1", "param2"]

#docker 