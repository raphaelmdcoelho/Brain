```
FROM ubuntu:latest
WORKDIR /app
COPY . .
RUN chmod
```

#docker 

