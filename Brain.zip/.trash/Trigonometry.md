

#math #trigonometry