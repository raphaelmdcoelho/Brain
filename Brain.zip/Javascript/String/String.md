- [[String.prototype.split()]]

#javascript 