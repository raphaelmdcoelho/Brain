- [[ECMAScript module system]]
- [[CommonJs]]

#javascript 