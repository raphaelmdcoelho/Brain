- [[Node]]

***Classes***

- [[Object]]
- [[String]]
- [[Array]]

***Methods***

[[eval()]]

***Tests***

- [[Jest]]

#javascript 
