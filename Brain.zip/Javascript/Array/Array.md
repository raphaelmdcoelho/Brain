- [[Array.prototype.reduce]]

#javascript