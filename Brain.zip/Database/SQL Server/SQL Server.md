- [[Pivot]]
- [[Merge]]
- [[Bulk Insert]]
- [[SELECT tips]]

#sqlserver 