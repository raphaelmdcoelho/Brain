- backup ?DB? FILE
- .changes on|off ==> *shows number of rows changed by a SQL*
- databases
- eqp on|off|full|... ==> *automatic EXPLAIN QUERY PLAN*
- .excel ==> *display output of next query command in spreadsheet*
- .import FILE TABLE ==> *import a data from a file into a table*
- .tables ?TABLE?

#sqlite
