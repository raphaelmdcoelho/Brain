
* AWK ➡️ Studied 10/01/2023.
	* Reviews: 
		* ✔️10/03/2023
		* ✔️10/10/2023
		* ✔️10/30/2023

<hr>

* ReactJS ➡️ (create app / routing / component / conditional / loop / forms)
* GIT ➡️ (interactive rebase)
* English ➡️ ??
* Trigonometry ➡️ (sen,cos,tan)
* AWK ➡️
* Xargs ➡️
* DotNet in a Nutshell ➡️
	* Reviews: 
		* ✔️11/21/2023

<hr>

*Always try to understand instead of just memorize!*

#reviewcalendar