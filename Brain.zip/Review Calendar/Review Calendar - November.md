➡️ React (component, ReactDom, conditional and JSX) => Studied  11/12/2023:

| Review Number | Date | Reviewed |
| -- | -- | -- |
| First Review | 11/13/2023 | ✔️ |
| Second Review | 11/15/2023 |  |
| Third Review | 12/05/2023 |  |

<hr>

*Always try to understand instead of just memorize!*

#reviewcalendar