* **Can**
	* Negative: Cannot / Can't
	* Tips: Pode.
* **Could**
	* Negative: Couldn't
	* Tips: Poderia se tivesse.
* **Would**
	* Negative: Wouldn't
* **Should**
	* Negative: Shouldn't
	* Tips: Deveria.
* **May**
	* Negative: May not
	* Tips: Possibility or Permission
* **Might**
	* Negative: Mightn't
* **Must**
	* Negative: Mustn't
	* Tips: It's a demand. Period.

* **Question**: Modal verb + subject + verb

#english 