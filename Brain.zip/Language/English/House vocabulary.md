- To sleep the floor (use brush)
- To mop the floor
- Put away
- To dust (remove dust)
- To wipe down (clean objects)
- Do the dishes (clean dishes)
- clean out (clean the refrigeretor)
- To do the laundry (clean, dry and fold the clothes)
- To hang out the laundry (pendurar)
- To make the bed

#english 