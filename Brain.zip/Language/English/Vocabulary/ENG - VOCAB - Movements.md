* Wink
* Blink
* Blow your nose
* Sneeze
* Whistle
* Giggle
* Whisper
* Snap fingers
* Nod
* Cough
* Plug eyes
* Cup ears
* Pinch
* Flick
* Tickle
* Shrug
* Hug
* Slip
* Hop
* Frown

#english