* Gooey: Wet and sticky in a good way, like melted cheese.
* Greasy: Taste of oil and leaves oil behind.
* Crunchy: Can be hard and make a loud sound when eating.
* Crumbly: Falls into small pieces when you break it or eat it. like cookie.
* Creamy: Smooth, soft and thick, usually made of milk or creamy.
* Crisp: Dry, hard outside that breaks easily and feels good.
* Moist: Soft and slightly wet, like cake.
* Chewy: Bubble gum.
* Sticky: Caramel.
* Tener: Soft and tears easily.

#english 