* Add -Ed to the end of regular verbs.
* Questions should use the auxiliary verb: `did`.
* Questions should keep the main verb at the present because the auxiliary verb `did`.

#english 