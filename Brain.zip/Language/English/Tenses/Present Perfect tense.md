### Concepts

Refers to things that happened in the past until the present.
Something that just happened.
Happened but I don't know when.
Something happening many times in my life.
When want to say never, like: `I have never eaten shrimps.`
! When using `just` is good to use Present Perfect since is something that just happened.
# Structure

**Affirmative**
* ==have/has + verb in past participle==.

**Question**
* ==Has he eaten at the restaurant==?

**Negative**
* ==He hasn't eaten at the restaurant==.

### Examples

```
I have been a software developer for 7 years.
```

#english
