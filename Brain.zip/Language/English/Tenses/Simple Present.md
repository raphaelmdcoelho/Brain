* Affirmative Phrases and habits
* Questions need the have the auxiliar verb: `do/does`.
* It/she and he should and letter ==S== to the end of the verb.

#english 