### Concepts

Things that happed in the past but are finished in the past.

# Structure

* ==had + verb in past participle==.

#english