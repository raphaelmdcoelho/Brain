* Auxiliary verb ==Will==
* Can use "Going to"

#english 