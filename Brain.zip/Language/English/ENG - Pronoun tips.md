* **Someone**
	* Positive sentences.
* **Somebody**
	* Positive sentences.
* **Anyone**
	* Negative sentences.
* **Anybody**
	* Negative sentences.

#english 