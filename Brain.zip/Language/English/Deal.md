What his/her/their deal? -> what's their problem / whats their situation.
- Deal with it -> it's your problem / stop complaning and move on.
- Deal me in -> I want to be part of it.
- That guy is a dealer -> give out drugs.
- Who will deal with it? -> Who will be responsable for this.
- What's the big deal -> It's not important.
- He is a big deal -> It's important.
- It's a deal -> Agreement.

#english
