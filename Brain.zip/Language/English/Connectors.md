### Addition

* and.

* Besides (begin of the phrase).
* In addition: In addition to dancing, I like reading and writing.
* **Moreover**: I like dancing and writing. Moreover, I like cooking.
* Furthermore
* too.
* also.
* as well.

### Contrast

* but.

* However.
* However: I like dancing. However, I don't like singing.
* Nevertheless.
* Although: Although, I don't have money, I want to buy a house.
* Even thought.
* Despite
* In spite of.

### Cause and consequence

* so.

* Thus.
* Therefore.
* Since.
* As.

### Time / Sequence

* First.
* Second.
* Finally.
* After that.
* Then.

#english 