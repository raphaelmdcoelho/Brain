**SEIN** (to be)
* ich bin
* du bist
* er, sie, es ist
* wir sind
* ihr seid
* sie sind
* Sie sind - you (formal) are

e.g.:



<hr>

**HABEN** (to have)

* Ich haben
* du hast
* er, sie, es hat
* wir haben
* ihr habt
* sie haben
* Sie haben - you (formal)

e.g.:

<hr>

**WERDEN** (to get, to become)

* ich werde 
* du wirst
* er, sie, es wird
* wir werden
* ihr werdet
* sie werden
* Sie werden

e.g.:

<hr>

**KÖNNEN** (can, to be able to)

* ich kann
* du kannst
* er, sie, es kann
* wir können
* ihr könnt
* sie können
* Sie können

e.g.:

<hr>

**MÜSSEN** (must, to have to)

* ich muss
* du musst
* er, sie, es muss
* wir müssen
* ihr müsst
* sie müssen
* Sie müssen

e.g.:

#german 