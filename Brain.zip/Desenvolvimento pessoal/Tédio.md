- Resíduos de atenção. (https://youtu.be/UYmwUEiDT2Q?si=F-K6RSbYSE-Dxq2)

#memória