- Iterative
	- git rebase "branch" --iterative
		- squash (merge the commits)
		- fixup (merge the commit and the messages)

#git 