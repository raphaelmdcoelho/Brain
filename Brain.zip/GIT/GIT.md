- [[GIT Rebase]]
- git commit -am "message"
- git config --global alias.ac "commit -am"
- git commit --amend -m "message"
- git commit --amend --no-edit
- git [[GIT Revert]] "hash"
- git log --oneline
- git stash save "name"
- git stash list
- git stash apply "index number"
- git branch -M "name"
- git log --graph --oneline --decorate
- [[GIT Bisect]]
- git clean -df (remove untracked files)
- git check-out -
- [[GIT Stash]]

#git 